<?php
$con = mysqli_connect('localhost','jorge10_bank','bank123','jorge10_bank') or die(mysqli_error($con));
?>
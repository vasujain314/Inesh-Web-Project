<?php
$con = mysqli_connect('localhost','root','','webmail') or die(mysqli_error($con));
?>
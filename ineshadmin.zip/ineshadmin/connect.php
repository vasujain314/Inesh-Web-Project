<?php
$con = mysqli_connect("localhost","root","ats12345","partyScenes")
?>